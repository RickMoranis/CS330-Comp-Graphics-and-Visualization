// Activate the VBOs contained within the mesh's VAO			(Tree Top 1)
glBindVertexArray(meshes.gSphereMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(7.25f, 9.5f, 5.25f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(13.0f, 32.0f, -185.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));


glBindTexture(GL_TEXTURE_2D, gTextureIdTree);

// Draws the triangles
glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);



// Activate the VBOs contained within the mesh's VAO		(Tree Trunk  2)
glBindVertexArray(meshes.gCylinderMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(0.5f, 8.0f, 0.5f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(24.0f, 18.0f, -175.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

// bind textures on corresponding texture units
//glActiveTexture(GL_TEXTURE0);
glBindTexture(GL_TEXTURE_2D, gTextureIdBark);


// Draws the triangles
glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
// Unbind the texture after rendering the putting green VBO
glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO			(Tree Top 2)
glBindVertexArray(meshes.gSphereMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(8.75f, 12.5f, 5.25f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(24.0f, 36.5f, -175.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

glBindTexture(GL_TEXTURE_2D, gTextureIdTree);

// Draws the triangles
glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO		(Tree Trunk  3)
glBindVertexArray(meshes.gCylinderMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(0.5f, 8.0f, 0.5f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(7.0f, 20.0f, -178.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

// bind textures on corresponding texture units
//glActiveTexture(GL_TEXTURE0);
glBindTexture(GL_TEXTURE_2D, gTextureIdBark);

// Draws the triangles
glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
// Unbind the texture after rendering the putting green VBO
glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO			(Tree Top 3)
glBindVertexArray(meshes.gSphereMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(6.75f, 7.5f, 5.25f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(7.0f, 28.0f, -178.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

glBindTexture(GL_TEXTURE_2D, gTextureIdTree);

// Draws the triangles
glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO		(Tree Trunk  4)
glBindVertexArray(meshes.gCylinderMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(0.5f, 8.0f, 0.5f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(1.0f, 20.0f, -182.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

// bind textures on corresponding texture units
//glActiveTexture(GL_TEXTURE0);
glBindTexture(GL_TEXTURE_2D, gTextureIdBark);

glGenerateMipmap(GL_TEXTURE_2D);

// Set the mipmap filtering mode for better visual quality
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

// Draws the triangles
glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
// Unbind the texture after rendering the putting green VBO
glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO			(Tree Top 4)
glBindVertexArray(meshes.gSphereMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(6.75f, 10.5f, 4.25f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(1.0f, 34.0f, -182.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

glBindTexture(GL_TEXTURE_2D, gTextureIdTree);

// Draws the triangles
glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);
// Activate the VBOs contained within the mesh's VAO		(Tree Trunk  5)
glBindVertexArray(meshes.gCylinderMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(0.5f, 8.0f, 0.5f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-4.0f, 20.0f, -185.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

// bind textures on corresponding texture units
//glActiveTexture(GL_TEXTURE0);
glBindTexture(GL_TEXTURE_2D, gTextureIdBark);

glGenerateMipmap(GL_TEXTURE_2D);

// Set the mipmap filtering mode for better visual quality
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

// Draws the triangles
glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
// Unbind the texture after rendering the putting green VBO
glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO			(Tree Top 5)
glBindVertexArray(meshes.gSphereMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(7.25f, 9.5f, 5.25f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-4.0f, 34.0f, -185.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));


glBindTexture(GL_TEXTURE_2D, gTextureIdTree);

// Draws the triangles
glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);



// Activate the VBOs contained within the mesh's VAO		(Tree Trunk  6)
glBindVertexArray(meshes.gCylinderMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(0.5f, 8.0f, 0.5f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-22.0f, 20.0f, -179.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

// bind textures on corresponding texture units
//glActiveTexture(GL_TEXTURE0);
glBindTexture(GL_TEXTURE_2D, gTextureIdBark);


// Draws the triangles
glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
// Unbind the texture after rendering the putting green VBO
glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO			(Tree Top 6)
glBindVertexArray(meshes.gSphereMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(7.75f, 6.5f, 5.25f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-22.0f, 31.0f, -179.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

glBindTexture(GL_TEXTURE_2D, gTextureIdTree);

// Draws the triangles
glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO		(Tree Trunk  7)
glBindVertexArray(meshes.gCylinderMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(0.5f, 8.0f, 0.5f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-11.0f, 18.0f, -174.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

// bind textures on corresponding texture units
//glActiveTexture(GL_TEXTURE0);
glBindTexture(GL_TEXTURE_2D, gTextureIdBark);

// Draws the triangles
glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
// Unbind the texture after rendering the putting green VBO
glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO			(Tree Top 7)
glBindVertexArray(meshes.gSphereMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(6.75f, 7.5f, 5.25f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-11.0f, 30.0f, -174.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

glBindTexture(GL_TEXTURE_2D, gTextureIdTree);

// Draws the triangles
glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO		(Tree Trunk  8)
glBindVertexArray(meshes.gCylinderMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(0.5f, 8.0f, 0.5f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-18.0f, 20.0f, -172.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

// bind textures on corresponding texture units
//glActiveTexture(GL_TEXTURE0);
glBindTexture(GL_TEXTURE_2D, gTextureIdBark);

glGenerateMipmap(GL_TEXTURE_2D);

// Set the mipmap filtering mode for better visual quality
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

// Draws the triangles
glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
// Unbind the texture after rendering the putting green VBO
glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO			(Tree Top 8)
glBindVertexArray(meshes.gSphereMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(6.75f, 10.5f, 4.25f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-18.0f, 34.0f, -172.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

glBindTexture(GL_TEXTURE_2D, gTextureIdTree);

// Draws the triangles
glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO		(Tree Trunk  9)
glBindVertexArray(meshes.gCylinderMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(0.5f, 8.0f, 0.5f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-27.0f, 23.0f, -190.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

// bind textures on corresponding texture units
//glActiveTexture(GL_TEXTURE0);
glBindTexture(GL_TEXTURE_2D, gTextureIdBark);

glGenerateMipmap(GL_TEXTURE_2D);

// Set the mipmap filtering mode for better visual quality
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

// Draws the triangles
glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
// Unbind the texture after rendering the putting green VBO
glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO			(Tree Top 9)
glBindVertexArray(meshes.gSphereMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(7.25f, 9.5f, 8.25f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-27.0f, 40.0f, -190.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));


glBindTexture(GL_TEXTURE_2D, gTextureIdTree);

// Draws the triangles
glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);



// Activate the VBOs contained within the mesh's VAO		(Tree Trunk  10)
glBindVertexArray(meshes.gCylinderMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(0.5f, 8.0f, 0.5f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-25.0f, 20.0f, -175.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

// bind textures on corresponding texture units
//glActiveTexture(GL_TEXTURE0);
glBindTexture(GL_TEXTURE_2D, gTextureIdBark);


// Draws the triangles
glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
// Unbind the texture after rendering the putting green VBO
glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO			(Tree Top 10)
glBindVertexArray(meshes.gSphereMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(7.75f, 11.5f, 7.75f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-25.0f, 35.0f, -175.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

glBindTexture(GL_TEXTURE_2D, gTextureIdTree);

// Draws the triangles
glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO		(Tree Trunk  11)
glBindVertexArray(meshes.gCylinderMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(0.5f, 11.0f, 0.5f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-29.0f, 20.0f, -183.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

// bind textures on corresponding texture units
//glActiveTexture(GL_TEXTURE0);
glBindTexture(GL_TEXTURE_2D, gTextureIdBark);

// Draws the triangles
glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
// Unbind the texture after rendering the putting green VBO
glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO			(Tree Top 11)
glBindVertexArray(meshes.gSphereMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(6.75f, 7.5f, 9.25f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-29.0f, 35.0f, -183.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

glBindTexture(GL_TEXTURE_2D, gTextureIdTree);

// Draws the triangles
glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO		(Tree Trunk  12)
glBindVertexArray(meshes.gCylinderMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(0.5f, 11.0f, 0.5f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-33.0f, 20.0f, -195.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

// bind textures on corresponding texture units
//glActiveTexture(GL_TEXTURE0);
glBindTexture(GL_TEXTURE_2D, gTextureIdBark);

glGenerateMipmap(GL_TEXTURE_2D);

// Set the mipmap filtering mode for better visual quality
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

// Draws the triangles
glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
// Unbind the texture after rendering the putting green VBO
glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO			(Tree Top 12)
glBindVertexArray(meshes.gSphereMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(6.75f, 10.5f, 6.25f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-33.0f, 39.0f, -195.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

glBindTexture(GL_TEXTURE_2D, gTextureIdTree);

// Draws the triangles
glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO		(Tree Trunk  13)
glBindVertexArray(meshes.gCylinderMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(0.5f, 11.0f, 0.5f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-36.0f, 20.0f, -179.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

// bind textures on corresponding texture units
//glActiveTexture(GL_TEXTURE0);
glBindTexture(GL_TEXTURE_2D, gTextureIdBark);


// Draws the triangles
glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
// Unbind the texture after rendering the putting green VBO
glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO			(Tree Top 13)
glBindVertexArray(meshes.gSphereMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(7.75f, 11.5f, 7.25f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-36.0f, 37.0f, -179.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

glBindTexture(GL_TEXTURE_2D, gTextureIdTree);

// Draws the triangles
glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO		(Tree Trunk  14)
glBindVertexArray(meshes.gCylinderMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(0.5f, 11.0f, 0.5f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-45.0f, 21.0f, -183.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

// bind textures on corresponding texture units
//glActiveTexture(GL_TEXTURE0);
glBindTexture(GL_TEXTURE_2D, gTextureIdBark);

// Draws the triangles
glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
// Unbind the texture after rendering the putting green VBO
glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO			(Tree Top 14)
glBindVertexArray(meshes.gSphereMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(6.75f, 9.5f, 5.25f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-45.0f, 35.0f, -183.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

glBindTexture(GL_TEXTURE_2D, gTextureIdTree);

// Draws the triangles
glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO		(Tree Trunk  15)
glBindVertexArray(meshes.gCylinderMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(0.5f, 11.0f, 0.5f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-49.0f, 20.0f, -185.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

// bind textures on corresponding texture units
//glActiveTexture(GL_TEXTURE0);
glBindTexture(GL_TEXTURE_2D, gTextureIdBark);

glGenerateMipmap(GL_TEXTURE_2D);

// Set the mipmap filtering mode for better visual quality
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

// Draws the triangles
glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
// Unbind the texture after rendering the putting green VBO
glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);

// Activate the VBOs contained within the mesh's VAO			(Tree Top 15)
glBindVertexArray(meshes.gSphereMesh.vao);

// 1. Scales the object
scale = glm::scale(glm::vec3(6.75f, 9.25f, 4.25f));
// 2. Rotate the object
rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
// 3. Position the object
translation = glm::translate(glm::vec3(-49.0f, 39.0f, -185.0f));
// Model matrix: transformations are applied right-to-left order
model = translation * rotation * scale;
glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

glBindTexture(GL_TEXTURE_2D, gTextureIdTree);

// Draws the triangles
glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

glBindTexture(GL_TEXTURE_2D, 0);

// Deactivate the Vertex Array Object
glBindVertexArray(0);